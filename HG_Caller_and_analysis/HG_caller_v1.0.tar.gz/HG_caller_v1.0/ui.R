

##############################
# Author: Cabrera-Alarcon JL #
##############################
# Load libraries
library(shiny)
library(shinyFiles)
library(shinyTree)
library(shinythemes)
library(caret)
library(dplyr)
library(irr)

# Define the user interface aspect of the Shiny app
options(shiny.maxRequestSize=1000*1024^2)
shinyUI(fluidPage(theme = shinytheme("spacelab"),
  imageOutput("image1", height = 100),
  HTML("<br><br>"),
  HTML("<br><br>"),
  titlePanel("mtHG-Caller v1.0"),
  navbarPage(
    title='Option:',
    tabPanel(
      title='mtHG-Caller:',
        sidebarPanel(fileInput("file", "Input file",accept = c(".tsv",".txt")),
        downloadButton("HG.list.Download", "Download data"), 
        HTML("<br><br>"),
        HTML("<br><br>"),
        HTML("<h3>Mitochondrial Haplogroups:</h3>"),
        dataTableOutput("Data.table")),
      mainPanel(
        verbatimTextOutput("kappa"),
        radioButtons("filter",label = "Apply filter", choices = c("Yes"="yes","No"="No"),selected = "No"),
        HTML("<h3>Phylogenetic tree of human mitochondrial DNA (mtDNA) haplogroups:</h3>"),
        uiOutput("HGtree"),
        HTML("<h3>Mitochondrial Haplogroups frequency:</h3>"),
        HTML("<br><br>"),
        tags$head(tags$style(type="text/css", "
             #loadmessage {
               position: fixed;
               top: 0px;
               left: 0px;
               width: 100%;
               padding: 5px 0px 5px 0px;
               text-align: center;
               font-weight: bold;
               font-size: 200%;
               color: #000000;
               background-color: #CCFF66;
               z-index: 105;
             }
          ")),
        conditionalPanel(condition="$('html').hasClass('shiny-busy')",
                         tags$div("Shiny App busy...",id="loadmessage")),
        plotOutput("plot01"),
        HTML("<br><br>"))
      ),
    tabPanel(
      title='HELP:',
      mainPanel(
        tags$h1('Instructions:'),
        tags$h4('Jose Luis Cabrera Alarcon'),
        tags$h6('2024-05-10'),
        tags$p('This is a shiny app to perform mitochondrial haplogroup, adapted to our GWAS array positions. However, it can do the mitochondrial haplogroup callin from any other genotype array, by traing an ad hoc model for your array.'),
        tags$p('Training a new model will take some additional minutes...'),
        tags$p('1. Click on “browser" to upload data from patients.'),
        tags$p('Uploaded data must be in tab separated values with ".tsv" or ".txt" extesion. This file must contain:'),
        tags$p(style="color:red",'Patient ID must be the uploaded as row names in the first column'),
        tags$p(style="color:red",'Your table should have many individual columns as covered mitochondrial genomic positions.'),
        imageOutput("image2", height = 250),
        HTML("<br><br>"),
        HTML("<br><br>"),
        HTML("<br><br>"),
        HTML("<br><br>"),
        HTML("<br><br>"),
        tags$p('2. While the app is running, the following message will appear at the top of the screen:'),
        imageOutput("image3", height = 250),
        HTML("<br><br>"),
        HTML("<br><br>"),
        HTML("<br><br>"),
        tags$p('3. The app mtHG-Caller v1.0 will display the results on the screen in two formats, interactive table (left side) and barplot specifying the proportion of each haplogroup in the analyzed sample (right side):'),
        imageOutput("image4", height = 250),
        HTML("<br><br>"),
        HTML("<br><br>"),
        HTML("<br><br>"),
        HTML("<br><br>"),
        HTML("<br><br>"),
        HTML("<br><br>"),
        tags$p("4. The app mtHG-Caller v1.0 will also show the model error as Cohen's kappa:"),
        imageOutput("image5", height = 250),
        HTML("<br><br>"),
        HTML("<br><br>"),
        HTML("<br><br>"),
        HTML("<br><br>"),
        tags$p('5. The app allows to display the results for specific branches or haplogroups, through the interactive tree that appears when selecting Apply filter "Yes":'),
        imageOutput("image6", height = 250),
        HTML("<br><br>"),
        HTML("<br><br>"),
        HTML("<br><br>"),
        HTML("<br><br>"),
        HTML("<br><br>"),
        tags$p('6. The app allows to download the results in csv format:'),
        imageOutput("image7", height = 250))
      
    ),
    tabPanel(
      title='ABOUT:',
      tags$h1('Authors:'),
      tags$p('José Luis Cabrera Alarcón (jlcabreraa@cnic.es)'),
      tags$h4('Powered by R Shiny.'))
    )
  )
)


