
# Check which individuals from query data are not classifiable due to have a genotype not included in training data for any of the probes 
identify_unclassifiable <- function(test, levels_train) {unclassifiable <- apply(test, 1, function(individual) {any(sapply(names(individual), function(var) {
      !(individual[[var]] %in% levels_train[[var]])
    }))
  })
  return(which(unclassifiable))
}

# List defining Haplogroup tree options
tree1 <- list(
  L1 = list('L1'),
  L2 = list('L2'),
  L3 = structure(list(
    L3='L3',
    M='M',
    N='N'),stopened=TRUE),
  L4 = list('L4'),
  L5 = list('L5'),
  L6 = list('L6')
)
tree2 <- list(
  L1 = list('L1'),
  L2 = list('L2'),
  L3 = structure(list(L3='L3',
    M = structure(list(CZ=structure(list(C= "C", Z = "Z"),stopened=TRUE),D = "D", E = "E",G = "G", Q = "Q",M='M'),stopened=TRUE),
    N = structure(list(O = "O", A = "A",S = "S", R = structure(list( B='B', F='F', HV=structure(list(HV='HV',H='H',V='V'),stopened=TRUE),
                         JT=structure(list(J='J',T='T'),stopened=TRUE), U=structure(list(U='U',K='K'),stopened=TRUE)),stopened=TRUE),
    I = "I", W = "W", X = "X",Y = "Y",N='N'),stopened=TRUE)),stopened=TRUE),
  L4 = list('L4'),
  L5 = list('L5'),
  L6 = list('L6')
)


