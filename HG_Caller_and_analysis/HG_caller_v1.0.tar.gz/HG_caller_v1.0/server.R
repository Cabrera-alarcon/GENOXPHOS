############################################## HG-Caller v1.0 ######################################################

# Load required environment
source('enviroment.R')

shinyServer(function(input, output, session) {
  
# Load query data-set in the appropriate format (described in Help sction)
  file.input<-reactive({
    req(input$file)
    inFile<-input$file
    df<-read.table(inFile$datapath, header = T, sep = '\t', dec = '.', check.names = FALSE,stringsAsFactors = FALSE,row.names = 1,colClasses = "character")
    dfm=read.delim(gzfile('./Mitomap.Haplogroup.markers.csv.gz'),sep = '\t',stringsAsFactors = F)
    df=df[,variable.names(df) %in% as.character(dfm$Pos)]
    return(df)
  })
# Use trained model or use our trained model
  modelFit=reactive({
    req(file.input())
    df.input=file.input()
    m=read.delim(gzfile('./train.tsv.gz'),sep = '\t', check.names = FALSE,stringsAsFactors = T,row.names = 1,colClasses = "character")
    m=cbind(Label=m[["Label"]],m[,variable.names(m) %in% variable.names(df.input)])
    
    # Create a tunegrid with 15 values from 1:15 for mtry to tunning model. Our train function will change number of entry variable at each split according to tunegrid. 
    set.seed(1)
    myGrid <- expand.grid(mtry = c(5, 10, 20, 40, 60),
                          splitrule = c("gini", "extratrees"),
                          min.node.size = 1) ## Minimal node size; default 1 for classification
    model <- train(Label ~ .,
                   data = m,
                   method = "ranger",
                   tuneGrid = myGrid,
                   trControl = trainControl(method = "cv",allowParallel = TRUE,number = 3,verboseIter = FALSE))

    return(model)
  })
  
# Annotate query data-set performing mitochondrial Haplogroup calling   
  datos<-reactive({
    req(file.input())
    req(modelFit())
    Patients<-file.input()
    model=modelFit()
    levels_train=lapply(model$trainingData[,-which(names(model$trainingData)=='.outcome')], function(x) if(is.factor(x)) levels(x) else unique(x))
    unclassifiable_indexes <- identify_unclassifiable(Patients[,which(colnames(Patients) %in% colnames(model$trainingData))], levels_train)
    if (length(unclassifiable_indexes)==nrow(Patients)) results.Patients=data.frame(ID=as.character(rownames(Patients)),HG=as.character(rep(x = 'Unclassified',nrow(Patients))))
    if (length(unclassifiable_indexes)>0 & length(unclassifiable_indexes)<nrow(Patients)){
      results.Patients=data.frame(ID=as.character(rownames(Patients)[-unclassifiable_indexes]),HG=as.character(as.factor(predict(model,Patients[-unclassifiable_indexes,]))))
      results.Patients.na=data.frame(ID=as.character(rownames(Patients)[unclassifiable_indexes]),HG=rep('-',length(unclassifiable_indexes)))
      results.Patients=rbind(results.Patients,results.Patients.na)
    } 
    if (length(unclassifiable_indexes)==0) results.Patients=data.frame(ID=as.character(rownames(Patients[-unclassifiable_indexes])),HG=as.character(as.factor(predict(model,Patients))))
    return(results.Patients)
  })
# Define a filter determining the Haplogroups to be represented, bot in the table and in the barplot  
  HGfilter=reactive({
    HGfilter=unique(unlist(get_selected(input$tree, format = "names")))
    return(HGfilter)
  })
# Display interactive tree for the selection of the Haplogroups to be represented
  output$title.barplot<-renderText('Mitochondrial Haplogroups frequencies')
  output$HGtree <- renderUI({
    input_type=input$filter
    if (input_type == 'yes'){
       shinyTree("tree", checkbox = TRUE,themeIcons=F)
    }
  })
  
# Define filtered data to be represented
  cases=reactive({
    req(modelFit())
    req(datos())
    df=datos()
    model=modelFit()
    test=read.delim(gzfile('./1000GP.tsv.gz'),sep = '\t',stringsAsFactors = F,colClasses = "character", header = T, row.names = 1, check.names = F)
    test=test[,which(names(test) %in% c(names(model$trainingData),'Label'))]
    return(test)
  })
# Calculate trained model error for haplogroup calling as Cohen's Kappa
  error=reactive({
    req(modelFit())
    df=cases()
    model=modelFit()
    levels_train=lapply(model$trainingData[,-which(names(model$trainingData)=='.outcome')], function(x) if(is.factor(x)) levels(x) else unique(x))
    unclassifiable_indexes <- identify_unclassifiable(df[,which(colnames(df) %in% colnames(model$trainingData))], levels_train)
    if (length(unclassifiable_indexes)>0) results.df=cbind(as.character(as.factor(df$Label[-unclassifiable_indexes])),as.character(as.factor(predict(model,df[-unclassifiable_indexes,]))))
    if (length(unclassifiable_indexes)==0) results.df=cbind(as.character(as.factor(df$Label)),as.character(as.factor(predict(model,df))))
    results.df.na=cbind(as.character(as.factor(df$Label[unclassifiable_indexes])),rep('-',length(unclassifiable_indexes)))
    results.df=rbind(results.df,results.df.na)
    k=kappa2(results.df)
    return(list(k$value,k$p.value))
  })
# Print Cohen's kappa
  output$kappa <- renderPrint({
    req(error())
    kappa <- error()
    return(paste0("Cohen's kappa = ", as.character(kappa[[1]]), "; p = ", as.character(kappa[[2]])))
  })
  
# Depict outcomes ina a barplot
  output$plot01<-renderPlot({
    par(cex=1.5)
    req(datos())
    Patients<-datos()
    if (!is.null(HGfilter())){
      HGfilter=unique(unlist(get_selected(input$tree, format = "names")))
      Patients=Patients %>% filter(HG %in% HGfilter)
    }
    
    Plot1=ggplot(Patients, aes(x = HG, fill=HG, label = scales::percent(prop.table(stat(count))))) +
      geom_bar() + ylim(0,max(table(Patients$HG))+20)+ 
      geom_text(stat = 'count',
                position = position_dodge(.9), 
                vjust = -0.5, 
                size = 3) + 
      labs(x = 'HG', y = 'Number of individual', fill = 'HG')+
      theme(legend.position = "none")
    
    return(Plot1)
  })

# Show outcomes in a table
  
  output$Data.table<-renderDataTable({
    req(datos())
    datos<-datos()
    if (!is.null(HGfilter())){
      HGfilter=unique(unlist(get_selected(input$tree, format = "names")))
      datos=datos %>% filter(HG %in% HGfilter)
    }
    return(datos)
  })
  
  output$tree <- renderTree({
    tree2
  })
# Show App's logo  
  output$image1 <- renderImage({
    filename <- normalizePath(file.path('./', paste('images', input$n, '.jpg', sep='')))
    # Return a list containing the filename
    list(src = filename)
  }, deleteFile = FALSE)
 
# Show explanatory image 1 in Help section  
  output$image2 <- renderImage({
    # When input$n is 1, filename is ./images/image1.jpeg
    filename <- normalizePath(file.path('./',paste('Figure', input$n, '.png', sep='')))
    # Return a list containing the filename
    list(src = filename)
  }, deleteFile = FALSE)

# Show explanatory image 2 in Help section  
  output$image3 <- renderImage({
    filename <- normalizePath(file.path('./', paste('Figure2', input$n, '.png', sep='')))
    list(src = filename)
  }, deleteFile = FALSE)

# Show explanatory image 3 in Help section  
  output$image4 <- renderImage({
    filename <- normalizePath(file.path('./', paste('Figure3', input$n, '.png', sep='')))
    list(src = filename)
  }, deleteFile = FALSE)

# Show explanatory image 4 in Help section  
  output$image5 <- renderImage({
    filename <- normalizePath(file.path('./', paste('Figure4', input$n, '.png', sep='')))
    list(src = filename)
  }, deleteFile = FALSE)

# Show explanatory image 5 in Help section  
  output$image6 <- renderImage({
    filename <- normalizePath(file.path('./', paste('Figure5', input$n, '.png', sep='')))
    list(src = filename)
  }, deleteFile = FALSE)
 
# Show explanatory image 6 in Help section  
  output$image7 <- renderImage({
    filename <- normalizePath(file.path('./', paste('Figure6', input$n, '.png', sep='')))
    list(src = filename)
  }, deleteFile = FALSE)
  
# Download results of Haplogroup calling    
  output$HG.list.Download <- downloadHandler(
    filename ='HG.list.csv',
    content = function(file) {
      datos<-datos()
      write.csv(datos, file, row.names = F, quote = FALSE)
    }
  )
})

  